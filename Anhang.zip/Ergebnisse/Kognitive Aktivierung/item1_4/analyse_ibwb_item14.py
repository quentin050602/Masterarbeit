import re
import json
import csv
from pathlib import Path

from openai import OpenAI

# ==============================
# EINSTELLUNGEN
# ==============================

# Ordner mit deinen Transkript-Textdateien (.txt)
# Für dein Setup: Ordner "Transkripte" im selben Verzeichnis wie dieses Skript.
TRANSCRIPTS_DIR = "Transkripte"

# Ausgabedateien
OUTPUT_INDICATORS_CSV = "indikatoren_pro_block.csv"
OUTPUT_BLOCK_SUMMARY_CSV = "block_summary.csv"

# OpenAI-Client (API-Key muss in OPENAI_API_KEY gesetzt sein,
# oder du setzt ihn hier explizit: OpenAI(api_key="DEIN_KEY"))
client = OpenAI()

# GPT-5.1 Thinking (Reasoning-Modell)
MODEL_NAME = "gpt-5.1"          # Modellname
REASONING_EFFORT = "medium"     # none, minimal, low, medium, high, xhigh


# ==============================
# PROMPT-BASIS
# ==============================

SYSTEM_PROMPT = """Du bist Expert*in für Unterrichtsqualitätsforschung und mit dem Unterrichtsfeedbackbogen Tiefenstrukturen (IBBW) vertraut.
Du analysierst Unterrichtstranskripte im Hinblick auf die Basisdimension „Kognitive Aktivierung“ und das Item 1.4 „Engagement der Schülerinnen und Schüler“.

Halte dich exakt an folgende Grundidee und Indikatoren (inklusive ID, Kategorie und Wortlaut). Du darfst an diesen Formulierungen NICHTS verändern:

1.4. ENGAGEMENT DER SCHÜLERINNEN UND SCHÜLER
Item Die Schülerinnen und Schüler sind engagiert am Unterrichtsgeschehen beteiligt. 
Grundidee Hinweis: Bei diesem Item wird das Verhalten der Schülerinnen und Schüler beobachtet. 
Dem Potenzial zur kognitiven Aktivierung des Unterrichts entspricht auf Seiten der Schülerinnen und Schüler eine kognitive Aktivität. Diese Aktivität selbst ist nicht beobachtbar. Dennoch gibt es beobachtbare Indikatoren, die darauf hinweisen, dass die Lernenden aktiv am Unterrichtsgeschehen beteiligt sind (vgl. Fredricks et al., 2019). Dazu gehören beispielsweise kritisches Nachfragen sowie die Bereitschaft, auch schwierige Probleme anzugehen und Inhalte verstehen zu wollen. 
Neben diesem kognitiven Engagement der Lernenden werden in der Literatur noch das Engagement auf der Verhaltensebene (Interaktionen mit der Lehrkraft oder den Mitschülerinnen und Mitschülern, Erledigung der Aufgaben) und der emotionalen Ebene (Zeigen von Interesse und Freude) unterschieden (Bond et al., 2020; Rimm-Kaufman et al., 2015). 
Bei der Einschätzung, inwieweit Lernende aktiv, d. h. engagiert, am Unterricht beteiligt sind, gibt es häufig das Missverständnis, dass die Schülerinnen und Schüler tatsächlich handelnd tätig sein müssten. Die motorische Aktivität ist jedoch nicht automatisch mit kognitiver Aktivität gleichzusetzen (Fauth & Leuders, 2022; Kleickmann, 2012). Mit dem vorliegenden Item soll deshalb anhand beobachtbarerer Indikatoren abgeleitet werden, inwieweit die Lernenden tatsächlich intensiv und tief über die Inhalte nachdenken und Verstehensprozesse angeregt werden. 
Dem entgegengesetzt steht ein passives Verhalten der Schülerinnen und Schüler im Unterricht. Dadurch stören sie zwar nicht den Unterrichtsfluss, ihr Engagement beschränkt sich aber primär darauf, auf das Verhalten der Lehrkraft zu reagieren. 

Die Indikatoren sind fest wie folgt definiert (ID, Kategorie, exakter Wortlaut):

Positivindikatoren
1 (positiv): Der Aufmerksamkeitsfokus der Schülerinnen und Schüler liegt auf dem Unterrichtsgeschehen.
2 (positiv): Die Schülerinnen und Schüler beteiligen sich durch Meldungen aktiv am Unterricht. 
3 (positiv): Die Schülerinnen und Schüler beteiligen sich auch mit längeren Beiträgen (nicht nur kurze Antworten auf Fragen der Lehrkraft) aktiv am Unterricht.
4 (positiv): Die Schülerinnen und Schüler stellen der Lehrkraft Fragen, wenn ihnen etwas ungeklärt oder unverständlich erscheint oder erklären, wie sie einen Sachverhalt verstanden haben, um zu erfahren, ob sie die Inhalte richtig nachvollzogen haben.
5 (positiv): Die Lernenden zeigen Interesse und Freude am Unterricht.

Negativindikatoren
6 (negativ): Die Schülerinnen und Schüler sind mit ihrer Aufmerksamkeit nicht beim Unterrichtsgeschehen („passives off-task Verhalten“).
7 (negativ): Die Schülerinnen und Schüler geben kurze, oberflächliche Antworten. 
8 (negativ): Die Schülerinnen und Schüler beteiligen sich nur auf explizite Aufforderung der Lehrkraft.
9 (negativ): Schülerinnen und Schüler geben bei schwierigen Aufgaben schnell auf. 
10 (negativ): Die Schülerinnen und Schüler wirken desinteressiert und lustlos.

Bewertungsskala Item-Gesamt:
1 – trifft nicht zu: deutliche Negativindikatoren, kaum/keine Positivindikatoren
2 – trifft eher nicht zu: Negativindikatoren überwiegen die Positivindikatoren
3 – trifft eher zu: Positivindikatoren überwiegen die Negativindikatoren
4 – trifft völlig zu: deutliche Positivindikatoren, kaum/keine Negativindikatoren.

WICHTIG:
- In deiner JSON-Antwort MUSST du für jeden Indikator GENAU diesen Wortlaut bei "indikator_text" verwenden (einschließlich Groß-/Kleinschreibung und Formulierung).
- Du darfst KEINE neuen Indikatoren hinzufügen und KEINE weglassen.
- Die Indikator-IDs (1–10) und die Kategorien ("positiv"/"negativ") sind ebenfalls fest vorgegeben.

Du antwortest ausschließlich im JSON-Format nach dem unten spezifizierten Schema.
Keine zusätzliche Prosa, keine Formatierung, nur gültiges JSON.
"""


# Wichtig: triple-single-quoted String, damit die """ im Text kein Problem machen
USER_INSTRUCTION_TEMPLATE = '''Analysiere das folgende Unterrichtstranskript (Block: {block_name}) im Hinblick auf das Item 1.4 „Engagement der Schülerinnen und Schüler“.

WICHTIG:
- Nutze ausschließlich die oben genannten Positiv- und Negativindikatoren mit den dort festgelegten IDs, Kategorien und exakten Formulierungen.
- Berücksichtige nur Informationen aus dem Transkript (inkl. Regieanweisungen).
- Für jeden der 10 Indikatoren MUSS es genau einen Eintrag geben.
- Bewertungscodes:
  * 1 = Indikator ist im Transkript klar erkennbar erfüllt / tritt auf
  * 0 = Indikator tritt im Transkript nicht auf
  * 99 = Indikator kann auf Basis des Transkripts nicht beurteilt werden
- Wenn 0: Begründung = „im Transkript nicht erkennbar“ (oder ähnlich knapp).
- Wenn 99: kurz begründen, WARUM nicht bewertbar (z.B. „keine Information zur Unterrichtsplanung“).

Gib deine Antwort in folgendem JSON-Schema zurück:

{{
  "block_name": "...",
  "indikatoren": [
    {{
      "indikator_id": 1-10,
      "indikator_text": "EXAKT einer der oben spezifizierten Indikatoren",
      "kategorie": "positiv" oder "negativ",
      "bewertung": 0 oder 1 oder 99,
      "begruendung": "kurze Textstelle oder Begründung"
    }}
  ],
  "anzahl_positive_1": <Zahl>,
  "anzahl_negative_1": <Zahl>,
  "gesamtbewertung": 1-4,
  "begruendung_gesamt": "3-5 Sätze zur Gesamtbewertung, mit explizitem Bezug auf Anzahl und Art der Indikatoren mit Bewertung = 1."
}}

Hier ist das Transkript:

"""text
{transcript}
"""
'''


# ==============================
# HILFSFUNKTIONEN
# ==============================

def extract_block_name_from_filename(filename: str) -> str:
    """Versucht aus dem Dateinamen etwas wie "Block 10" zu ziehen.
    Fallback: Dateiname ohne Endung.
    """
    base = Path(filename).stem
    m = re.search(r"(Block\s*\d+)", base, re.IGNORECASE)
    if m:
        return m.group(1)
    return base


def call_model(block_name: str, transcript: str) -> dict:
    """Ruft das OpenAI-Modell auf und gibt das geparste JSON zurück."""
    user_prompt = USER_INSTRUCTION_TEMPLATE.format(
        block_name=block_name,
        transcript=transcript
    )



    response = client.chat.completions.create(
        model=MODEL_NAME,
        temperature=0,
        reasoning_effort=REASONING_EFFORT,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]
    )


    content = response.choices[0].message.content.strip()

    try:
        data = json.loads(content)
    except json.JSONDecodeError as e:
        print(f"⚠️ JSON-Fehler bei Block {block_name}: {e}")
        print("Antwort war:")
        print(content)
        raise

    return data


def write_indicators_csv(results: list, output_path: str):
    """Schreibt eine CSV mit allen Indikatorzeilen."""
    fieldnames = [
        "block_name",
        "indikator_id",
        "indikator_text",
        "kategorie",
        "bewertung",
        "begruendung",
        "anzahl_positive_1",
        "anzahl_negative_1",
        "gesamtbewertung"
    ]

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()

        for block_result in results:
            block_name = block_result.get("block_name", "")
            anzahl_pos = block_result.get("anzahl_positive_1", "")
            anzahl_neg = block_result.get("anzahl_negative_1", "")
            gesamt = block_result.get("gesamtbewertung", "")
            for ind in block_result.get("indikatoren", []):
                row = {
                    "block_name": block_name,
                    "indikator_id": ind.get("indikator_id", ""),
                    "indikator_text": ind.get("indikator_text", ""),
                    "kategorie": ind.get("kategorie", ""),
                    "bewertung": ind.get("bewertung", ""),
                    "begruendung": ind.get("begruendung", ""),
                    "anzahl_positive_1": anzahl_pos,
                    "anzahl_negative_1": anzahl_neg,
                    "gesamtbewertung": gesamt,
                }
                writer.writerow(row)


def write_block_summary_csv(results: list, output_path: str):
    """Schreibt eine CSV pro Block mit Gesamtwerten."""
    fieldnames = [
        "block_name",
        "anzahl_positive_1",
        "anzahl_negative_1",
        "gesamtbewertung",
        "begruendung_gesamt"
    ]

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()

        for block_result in results:
            row = {
                "block_name": block_result.get("block_name", ""),
                "anzahl_positive_1": block_result.get("anzahl_positive_1", ""),
                "anzahl_negative_1": block_result.get("anzahl_negative_1", ""),
                "gesamtbewertung": block_result.get("gesamtbewertung", ""),
                "begruendung_gesamt": block_result.get("begruendung_gesamt", ""),
            }
            writer.writerow(row)


# ==============================
# HAUPTLAUF
# ==============================

def main():
    transcripts_dir = Path(TRANSCRIPTS_DIR)
    if not transcripts_dir.exists():
        print(f"❌ Ordner {transcripts_dir} existiert nicht. Bitte anpassen.")
        return

    txt_files = sorted(transcripts_dir.glob("*.txt"))
    if not txt_files:
        print(f"❌ Keine .txt-Dateien in {transcripts_dir} gefunden.")
        return

    all_results = []

    for path in txt_files:
        print(f"➡️  Analysiere Datei: {path.name}")
        text = path.read_text(encoding="utf-8")
        block_name = extract_block_name_from_filename(path.name)

        block_result = call_model(block_name, text)
        all_results.append(block_result)

        print(f"✅ Fertig: {block_name} (Gesamtbewertung: {block_result.get('gesamtbewertung')})")

    write_indicators_csv(all_results, OUTPUT_INDICATORS_CSV)
    write_block_summary_csv(all_results, OUTPUT_BLOCK_SUMMARY_CSV)

    print("📁 Export abgeschlossen:")
    print(f"- Indikatoren: {OUTPUT_INDICATORS_CSV}")
    print(f"- Block-Summary: {OUTPUT_BLOCK_SUMMARY_CSV}")


if __name__ == "__main__":
    main()

