import re
import json
import csv
from pathlib import Path

from openai import OpenAI

# ==============================
# EINSTELLUNGEN
# ==============================

# Ordner mit deinen Transkript-Textdateien (.txt)
# Für dein Setup: Ordner "Transkripte" im selben Verzeichnis wie dieses Skript.
TRANSCRIPTS_DIR = "Transkripte"

# Ausgabedateien
OUTPUT_INDICATORS_CSV = "indikatoren_pro_block.csv"
OUTPUT_BLOCK_SUMMARY_CSV = "block_summary.csv"

# OpenAI-Client (API-Key muss in OPENAI_API_KEY gesetzt sein,
# oder du setzt ihn hier explizit: OpenAI(api_key="DEIN_KEY"))
client = OpenAI()

# GPT-5.1 Thinking (Reasoning-Modell)
MODEL_NAME = "gpt-5.1"          # Modellname
REASONING_EFFORT = "medium"     # none, minimal, low, medium, high, xhigh


# ==============================
# PROMPT-BASIS
# ==============================

SYSTEM_PROMPT = """Du bist Expert*in für Unterrichtsqualitätsforschung und mit dem Unterrichtsfeedbackbogen Tiefenstrukturen (IBBW) vertraut.
Du analysierst Unterrichtstranskripte im Hinblick auf die Basisdimension „Strukturierte Klassenführung“ und das Item 3.2 „Monitoring“.

Halte dich exakt an folgende Grundidee und Indikatoren:

3.2. MONITORING
Item Die Lehrkraft hat einen guten Überblick über das Geschehen im Unterricht.
Grundidee Dieses Item erfasst das Maß, in dem die Lehrkraft im Klassenzimmer „allgegenwärtig“ ist, Präsenz zeigt und auf Störungen reagiert (Gabriel & Lipowsky, 2013a). Demnach werden bei diesem Item 1.) das störungspräventive Verhalten der Lehrkraft sowie 2.) Maßnahmen der Störungsintervention berücksichtigt. 
1.) Die Lehrkraft vermittelt den Eindruck, zu jedem Zeitpunkt über alle Schüleraktivitäten informiert zu sein und ihre Klasse immer und überall im Blick zu haben. Dazu gehört auch, dass sie den Überblick und die Kontrolle über die gesamte Klasse nicht verliert, wenn sie sich einzelnen Schülerinnen und Schülern zuwendet (beispielsweise bei Verhaltensproblemen oder der Unterstützung Einzelner) oder an der Tafel oder ihrem Pult arbeitet. Sie hat sprichwörtlich „Augen im Hinterkopf“ (Gabriel & Lipowsky, 2013a). Diese Dimension erfasst damit, inwiefern die Lehrkraft störungspräventives Verhalten zeigt, um Störungen und Unruhe gar nicht erst entstehen zu lassen (Rakoczy & Pauli, 2006).
2.) Ergänzend zum gezeigten störungspräventiven Verhalten wird erfasst, inwieweit die Lehrkraft bei Störungen (siehe Item 3.1) intervenierend eingreift. Eine angemessene Reaktion der Lehrkraft auf Störungen führt dazu, dass diese schnell und ohne den Unterricht zusätzlich zu unterbrechen, beendet werden. Situationsabhängig kann es allerdings auch sinnvoll und notwendig sein, Störungen gezielt zu adressieren und im weiteren Unterrichtsverlauf darauf einzugehen.

Positivindikatoren
• Die Lehrkraft hat alle Schülerinnen und Schüler im Blick.
• Die Lehrkraft ist im ganzen Klassenzimmer präsent (z. B. durch Blicke oder Bewegungen), auch während Einzelarbeitsphasen.
• Die Lehrkraft kehrt den Schülerinnen und Schülern nur selten den Rücken zu und richtet ihren Blick meist zur Klasse.
• Die Lehrkraft geht mit Störungen, die den Unterrichtsfluss gefährden, angemessen um.
• Aufkeimende Störungen behebt die Lehrkraft frühzeitig und beiläufig, sodass es erst gar nicht zu Unruhe oder Störungen kommt (z. B. durch nonverbale/verbale Signale wie räumliches Annähern, Blicke oder Gesten).

Negativindikatoren
• Im Gespräch mit einzelnen Schülerinnen und Schülern verliert die Lehrkraft die restliche Klasse aus dem Blick.
• Die Lehrkraft steht häufig mit dem Rücken zur Klasse.
• Die Lehrkraft bemerkt einzelne Schülermeldungen oft nicht oder erst spät.
• Die Lehrkraft verfügt über ein eingeschränktes Verhaltensrepertoire zur Reaktion auf Störungen (z. B. häufiges „Pst“).
• Die Lehrkraft gibt Störungen so viel Raum, dass eine Beschäftigung mit den Unterrichtsinhalten nur noch eingeschränkt möglich ist.

Bewertungsskala Item-Gesamt:
1 – trifft nicht zu: deutliche Negativindikatoren, kaum/keine Positivindikatoren
2 – trifft eher nicht zu: Negativindikatoren überwiegen die Positivindikatoren
3 – trifft eher zu: Positivindikatoren überwiegen die Negativindikatoren
4 – trifft völlig zu: deutliche Positivindikatoren, kaum/keine Negativindikatoren.

Du antwortest ausschließlich im JSON-Format nach dem unten spezifizierten Schema.
Keine zusätzliche Prosa, keine Formatierung, nur gültiges JSON.
"""

# Wichtig: triple-single-quoted String, damit die """ im Text kein Problem machen
USER_INSTRUCTION_TEMPLATE = '''Analysiere das folgende Unterrichtstranskript (Block: {block_name}) im Hinblick auf das Item 3.2 „Monitoring“.

WICHTIG:
- Nutze ausschließlich die oben genannten Positiv- und Negativindikatoren mit den dort festgelegten IDs, Kategorien und exakten Formulierungen.
- Berücksichtige nur Informationen aus dem Transkript (inkl. Regieanweisungen).
- Für jeden der 10 Indikatoren MUSS es genau einen Eintrag geben.
- Bewertungscodes:
  * 1 = Indikator ist im Transkript klar erkennbar erfüllt / tritt auf
  * 0 = Indikator tritt im Transkript nicht auf
  * 99 = Indikator kann auf Basis des Transkripts nicht beurteilt werden
- Wenn 0: Begründung = „im Transkript nicht erkennbar“ (oder ähnlich knapp).
- Wenn 99: kurz begründen, WARUM nicht bewertbar (z.B. „keine Information zur Unterrichtsplanung“).

Gib deine Antwort in folgendem JSON-Schema zurück:

{{
  "block_name": "...",
  "indikatoren": [
    {{
      "indikator_id": 1-10,
      "indikator_text": "EXAKT einer der oben spezifizierten Indikatoren",
      "kategorie": "positiv" oder "negativ",
      "bewertung": 0 oder 1 oder 99,
      "begruendung": "kurze Textstelle oder Begründung"
    }}
  ],
  "anzahl_positive_1": <Zahl>,
  "anzahl_negative_1": <Zahl>,
  "gesamtbewertung": 1-4,
  "begruendung_gesamt": "3-5 Sätze zur Gesamtbewertung, mit explizitem Bezug auf Anzahl und Art der Indikatoren mit Bewertung = 1."
}}

Hier ist das Transkript:

"""text
{transcript}
"""
'''





# ==============================
# HILFSFUNKTIONEN
# ==============================

def extract_block_name_from_filename(filename: str) -> str:
    """Versucht aus dem Dateinamen etwas wie "Block 10" zu ziehen.
    Fallback: Dateiname ohne Endung.
    """
    base = Path(filename).stem
    m = re.search(r"(Block\s*\d+)", base, re.IGNORECASE)
    if m:
        return m.group(1)
    return base


def call_model(block_name: str, transcript: str) -> dict:
    """Ruft das OpenAI-Modell auf und gibt das geparste JSON zurück."""
    user_prompt = USER_INSTRUCTION_TEMPLATE.format(
        block_name=block_name,
        transcript=transcript
    )



    response = client.chat.completions.create(
        model=MODEL_NAME,
        temperature=0,
        reasoning_effort=REASONING_EFFORT,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]
    )


    content = response.choices[0].message.content.strip()

    try:
        data = json.loads(content)
    except json.JSONDecodeError as e:
        print(f"⚠️ JSON-Fehler bei Block {block_name}: {e}")
        print("Antwort war:")
        print(content)
        raise

    return data


def write_indicators_csv(results: list, output_path: str):
    """Schreibt eine CSV mit allen Indikatorzeilen."""
    fieldnames = [
        "block_name",
        "indikator_id",
        "indikator_text",
        "kategorie",
        "bewertung",
        "begruendung",
        "anzahl_positive_1",
        "anzahl_negative_1",
        "gesamtbewertung"
    ]

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()

        for block_result in results:
            block_name = block_result.get("block_name", "")
            anzahl_pos = block_result.get("anzahl_positive_1", "")
            anzahl_neg = block_result.get("anzahl_negative_1", "")
            gesamt = block_result.get("gesamtbewertung", "")
            for ind in block_result.get("indikatoren", []):
                row = {
                    "block_name": block_name,
                    "indikator_id": ind.get("indikator_id", ""),
                    "indikator_text": ind.get("indikator_text", ""),
                    "kategorie": ind.get("kategorie", ""),
                    "bewertung": ind.get("bewertung", ""),
                    "begruendung": ind.get("begruendung", ""),
                    "anzahl_positive_1": anzahl_pos,
                    "anzahl_negative_1": anzahl_neg,
                    "gesamtbewertung": gesamt,
                }
                writer.writerow(row)


def write_block_summary_csv(results: list, output_path: str):
    """Schreibt eine CSV pro Block mit Gesamtwerten."""
    fieldnames = [
        "block_name",
        "anzahl_positive_1",
        "anzahl_negative_1",
        "gesamtbewertung",
        "begruendung_gesamt"
    ]

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()

        for block_result in results:
            row = {
                "block_name": block_result.get("block_name", ""),
                "anzahl_positive_1": block_result.get("anzahl_positive_1", ""),
                "anzahl_negative_1": block_result.get("anzahl_negative_1", ""),
                "gesamtbewertung": block_result.get("gesamtbewertung", ""),
                "begruendung_gesamt": block_result.get("begruendung_gesamt", ""),
            }
            writer.writerow(row)


# ==============================
# HAUPTLAUF
# ==============================

def main():
    transcripts_dir = Path(TRANSCRIPTS_DIR)
    if not transcripts_dir.exists():
        print(f"❌ Ordner {transcripts_dir} existiert nicht. Bitte anpassen.")
        return

    txt_files = sorted(transcripts_dir.glob("*.txt"))
    if not txt_files:
        print(f"❌ Keine .txt-Dateien in {transcripts_dir} gefunden.")
        return

    all_results = []

    for path in txt_files:
        print(f"➡️  Analysiere Datei: {path.name}")
        text = path.read_text(encoding="utf-8")
        block_name = extract_block_name_from_filename(path.name)

        block_result = call_model(block_name, text)
        all_results.append(block_result)

        print(f"✅ Fertig: {block_name} (Gesamtbewertung: {block_result.get('gesamtbewertung')})")

    write_indicators_csv(all_results, OUTPUT_INDICATORS_CSV)
    write_block_summary_csv(all_results, OUTPUT_BLOCK_SUMMARY_CSV)

    print("📁 Export abgeschlossen:")
    print(f"- Indikatoren: {OUTPUT_INDICATORS_CSV}")
    print(f"- Block-Summary: {OUTPUT_BLOCK_SUMMARY_CSV}")


if __name__ == "__main__":
    main()

