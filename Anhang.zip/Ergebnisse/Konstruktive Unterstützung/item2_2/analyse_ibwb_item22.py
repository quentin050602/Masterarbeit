import re
import json
import csv
from pathlib import Path

from openai import OpenAI

# ==============================
# EINSTELLUNGEN
# ==============================

# Ordner mit deinen Transkript-Textdateien (.txt)
# Für dein Setup: Ordner "Transkripte" im selben Verzeichnis wie dieses Skript.
TRANSCRIPTS_DIR = "Transkripte"

# Ausgabedateien
OUTPUT_INDICATORS_CSV = "indikatoren_pro_block.csv"
OUTPUT_BLOCK_SUMMARY_CSV = "block_summary.csv"

# OpenAI-Client (API-Key muss in OPENAI_API_KEY gesetzt sein,
# oder du setzt ihn hier explizit: OpenAI(api_key="DEIN_KEY"))
client = OpenAI()

# GPT-5.1 Thinking (Reasoning-Modell)
MODEL_NAME = "gpt-5.1"          # Modellname
REASONING_EFFORT = "medium"     # none, minimal, low, medium, high, xhigh


# ==============================
# PROMPT-BASIS
# ==============================

SYSTEM_PROMPT = """Du bist Expert*in für Unterrichtsqualitätsforschung und mit dem Unterrichtsfeedbackbogen Tiefenstrukturen (IBBW) vertraut.
Du analysierst Unterrichtstranskripte im Hinblick auf die Basisdimension „Konstruktive Unterstützung“ und das Item 2.2 „Individuelle Unterstützung im Lernprozess“.

Halte dich exakt an folgende Grundidee und Indikatoren (inklusive ID, Kategorie und Wortlaut). Du darfst an diesen Formulierungen NICHTS verändern:

2.2. INDIVIDUELLE UNTERSTÜTZUNG IM LERNPROZESS
Item Die Lehrkraft unterstützt die Schülerinnen und Schüler individuell in ihrem Lernprozess.
Grundidee Die konstruktive Unterstützung in methodisch-didaktischer Hinsicht zeichnet sich durch Hilfestellungen beim Wissenserwerb aus. Diese sind vor allem bei Verständnisproblemen von besonderer Bedeutung und müssen hierbei an individuelle Lernvoraussetzungen der Schülerinnen und Schüler angepasst werden. Die Lehrkraft steht vor der Herausforderung, ihr Lehrangebot an den aktuellen Lernstand der Schülerinnen und Schüler anzupassen und somit eine individuelle Förderung zu erreichen (Sliwka et al., 2022). Beim sogenannten „Scaffolding“ bietet die Lehrkraft genau jene strukturierenden Maßnahmen und Hilfestellungen an, die ihre Schülerinnen und Schüler zur selbstständigen Bewältigung einer Aufgabe benötigen. Das heißt, die Unterstützung ist vorübergehend und wird schrittweise reduziert, während die Lernenden die entsprechenden Fähigkeiten erwerben. Dies soll für jeden Lernenden ein Lernen in der individuellen „Zone der nächsten Entwicklung“ ermöglichen. 
Die Umsetzung der individuellen Hilfestellungen kann auf der Makroebene durch die richtige Unterrichtsplanung und -vorbereitung erreicht werden, z. B. durch differenzierende Materialien für unterschiedliche Leistungsniveaus. Auf der Mikroebene zeigen sie sich vor allem in den ad-hoc Interaktionen zwischen der Lehrkraft und ihren Schülerinnen und Schülern durch die passende Unterstützung nach Bedarf (Sliwka et al., 2022). Ziel dieser Art der Unterstützung der Lernenden ist es, die Passung des Lernangebots zu den individuellen Bedarfen der Lernenden zu erhöhen („adaptiver Unterricht“; vgl. Dumont, 2018). 

Die Indikatoren sind fest wie folgt definiert (ID, Kategorie, exakter Wortlaut):

Positivindikatoren
1 (positiv): Die Lehrkraft nimmt sich bei Verständnisproblemen gezielt Zeit für einzelne Schülerinnen und Schüler.
2 (positiv): Nach Rückfragen erklärt die Lehrkraft klar und verständlich.
3 (positiv): Unterstützende Maßnahmen und Hilfestellungen der Lehrkraft sind individuell an den Lernstand der Schülerinnen und Schüler angepasst.
4 (positiv): Die Lehrkraft ermöglicht, z. B. durch individualisierte Arbeitsphasen, eine Differenzierung des Anspruchsniveaus, des Lerntempos und/oder der Inhalte.
5 (positiv): Die Lehrkraft gibt den Schülerinnen und Schülern genug Zeit, um überlegt auf Fragen antworten zu können.
6 (positiv): Die Lehrkraft bietet Hilfen bei sprachlichen Barrieren an.

Negativindikatoren
7 (negativ): Den Schülerinnen und Schülern wird durch zu enggeführte Erklärung die Möglichkeit genommen, sich Inhalte selbst zu erschließen.
8 (negativ): Die geforderten Aufgaben stellen für die Schülerinnen und Schüler eine offensichtliche Unter- oder Überforderung dar.
9 (negativ): Die geforderten Aufgaben können von den Schülerinnen und Schülern selbst mit Hilfe nicht bewältigt werden. 

Bewertungsskala Item-Gesamt:
1 – trifft nicht zu: deutliche Negativindikatoren, kaum/keine Positivindikatoren
2 – trifft eher nicht zu: Negativindikatoren überwiegen die Positivindikatoren
3 – trifft eher zu: Positivindikatoren überwiegen die Negativindikatoren
4 – trifft völlig zu: deutliche Positivindikatoren, kaum/keine Negativindikatoren.

WICHTIG:
- In deiner JSON-Antwort MUSST du für jeden Indikator GENAU diesen Wortlaut bei "indikator_text" verwenden (einschließlich Groß-/Kleinschreibung und Formulierung).
- Du darfst KEINE neuen Indikatoren hinzufügen und KEINE weglassen.
- Die Indikator-IDs (1–9) und die Kategorien ("positiv"/"negativ") sind ebenfalls fest vorgegeben.

Du antwortest ausschließlich im JSON-Format nach dem unten spezifizierten Schema.
Keine zusätzliche Prosa, keine Formatierung, nur gültiges JSON.
"""

# Wichtig: triple-single-quoted String, damit die """ im Text kein Problem machen
USER_INSTRUCTION_TEMPLATE = '''Analysiere das folgende Unterrichtstranskript (Block: {block_name}) im Hinblick auf das Item 2.2 „Individuelle Unterstützung im Lernprozess“.

WICHTIG:
- Nutze ausschließlich die oben genannten Positiv- und Negativindikatoren mit den dort festgelegten IDs, Kategorien und exakten Formulierungen.
- Berücksichtige nur Informationen aus dem Transkript (inkl. Regieanweisungen).
- Für jeden der 9 Indikatoren MUSS es genau einen Eintrag geben.
- Bewertungscodes:
  * 1 = Indikator ist im Transkript klar erkennbar erfüllt / tritt auf
  * 0 = Indikator tritt im Transkript nicht auf
  * 99 = Indikator kann auf Basis des Transkripts nicht beurteilt werden
- Wenn 0: Begründung = „im Transkript nicht erkennbar“ (oder ähnlich knapp).
- Wenn 99: kurz begründen, WARUM nicht bewertbar (z.B. „keine Information zur Unterrichtsplanung“).

Gib deine Antwort in folgendem JSON-Schema zurück:

{{
  "block_name": "...",
  "indikatoren": [
    {{
      "indikator_id": 1-9,
      "indikator_text": "EXAKT einer der oben spezifizierten Indikatoren",
      "kategorie": "positiv" oder "negativ",
      "bewertung": 0 oder 1 oder 99,
      "begruendung": "kurze Textstelle oder Begründung"
    }}
  ],
  "anzahl_positive_1": <Zahl>,
  "anzahl_negative_1": <Zahl>,
  "gesamtbewertung": 1-4,
  "begruendung_gesamt": "3-5 Sätze zur Gesamtbewertung, mit explizitem Bezug auf Anzahl und Art der Indikatoren mit Bewertung = 1."
}}

Hier ist das Transkript:

"""text
{transcript}
"""
'''




# ==============================
# HILFSFUNKTIONEN
# ==============================

def extract_block_name_from_filename(filename: str) -> str:
    """Versucht aus dem Dateinamen etwas wie "Block 10" zu ziehen.
    Fallback: Dateiname ohne Endung.
    """
    base = Path(filename).stem
    m = re.search(r"(Block\s*\d+)", base, re.IGNORECASE)
    if m:
        return m.group(1)
    return base


def call_model(block_name: str, transcript: str) -> dict:
    """Ruft das OpenAI-Modell auf und gibt das geparste JSON zurück."""
    user_prompt = USER_INSTRUCTION_TEMPLATE.format(
        block_name=block_name,
        transcript=transcript
    )



    response = client.chat.completions.create(
        model=MODEL_NAME,
        temperature=0,
        reasoning_effort=REASONING_EFFORT,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt}
        ]
    )


    content = response.choices[0].message.content.strip()

    try:
        data = json.loads(content)
    except json.JSONDecodeError as e:
        print(f"⚠️ JSON-Fehler bei Block {block_name}: {e}")
        print("Antwort war:")
        print(content)
        raise

    return data


def write_indicators_csv(results: list, output_path: str):
    """Schreibt eine CSV mit allen Indikatorzeilen."""
    fieldnames = [
        "block_name",
        "indikator_id",
        "indikator_text",
        "kategorie",
        "bewertung",
        "begruendung",
        "anzahl_positive_1",
        "anzahl_negative_1",
        "gesamtbewertung"
    ]

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()

        for block_result in results:
            block_name = block_result.get("block_name", "")
            anzahl_pos = block_result.get("anzahl_positive_1", "")
            anzahl_neg = block_result.get("anzahl_negative_1", "")
            gesamt = block_result.get("gesamtbewertung", "")
            for ind in block_result.get("indikatoren", []):
                row = {
                    "block_name": block_name,
                    "indikator_id": ind.get("indikator_id", ""),
                    "indikator_text": ind.get("indikator_text", ""),
                    "kategorie": ind.get("kategorie", ""),
                    "bewertung": ind.get("bewertung", ""),
                    "begruendung": ind.get("begruendung", ""),
                    "anzahl_positive_1": anzahl_pos,
                    "anzahl_negative_1": anzahl_neg,
                    "gesamtbewertung": gesamt,
                }
                writer.writerow(row)


def write_block_summary_csv(results: list, output_path: str):
    """Schreibt eine CSV pro Block mit Gesamtwerten."""
    fieldnames = [
        "block_name",
        "anzahl_positive_1",
        "anzahl_negative_1",
        "gesamtbewertung",
        "begruendung_gesamt"
    ]

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()

        for block_result in results:
            row = {
                "block_name": block_result.get("block_name", ""),
                "anzahl_positive_1": block_result.get("anzahl_positive_1", ""),
                "anzahl_negative_1": block_result.get("anzahl_negative_1", ""),
                "gesamtbewertung": block_result.get("gesamtbewertung", ""),
                "begruendung_gesamt": block_result.get("begruendung_gesamt", ""),
            }
            writer.writerow(row)


# ==============================
# HAUPTLAUF
# ==============================

def main():
    transcripts_dir = Path(TRANSCRIPTS_DIR)
    if not transcripts_dir.exists():
        print(f"❌ Ordner {transcripts_dir} existiert nicht. Bitte anpassen.")
        return

    txt_files = sorted(transcripts_dir.glob("*.txt"))
    if not txt_files:
        print(f"❌ Keine .txt-Dateien in {transcripts_dir} gefunden.")
        return

    all_results = []

    for path in txt_files:
        print(f"➡️  Analysiere Datei: {path.name}")
        text = path.read_text(encoding="utf-8")
        block_name = extract_block_name_from_filename(path.name)

        block_result = call_model(block_name, text)
        all_results.append(block_result)

        print(f"✅ Fertig: {block_name} (Gesamtbewertung: {block_result.get('gesamtbewertung')})")

    write_indicators_csv(all_results, OUTPUT_INDICATORS_CSV)
    write_block_summary_csv(all_results, OUTPUT_BLOCK_SUMMARY_CSV)

    print("📁 Export abgeschlossen:")
    print(f"- Indikatoren: {OUTPUT_INDICATORS_CSV}")
    print(f"- Block-Summary: {OUTPUT_BLOCK_SUMMARY_CSV}")


if __name__ == "__main__":
    main()

